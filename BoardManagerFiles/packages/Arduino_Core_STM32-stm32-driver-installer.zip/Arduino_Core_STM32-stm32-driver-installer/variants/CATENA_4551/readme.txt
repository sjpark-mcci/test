For background, see the stm32duino Wiki:
https://github.com/stm32duino/wiki/wiki/Add-a-new-variant-(board)